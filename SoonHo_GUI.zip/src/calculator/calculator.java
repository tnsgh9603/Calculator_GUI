package calculator;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.StringTokenizer;
import java.util.Vector;

public class calculator extends JFrame implements ActionListener {
	private JPanel panel, panel1, panel2;
	private JTextField tField, tField1;
	private JButton[] buttons;
	private String[] labels = { "7", "8", "9", "x", "4", "5", "6", "-", "1", "2", "3", "+", "CE", "0", "=", "/" };

	public calculator() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("�Ǽ�ȣ");
		setSize(400, 300);

		tField = new JTextField(15);
		tField1 = new JTextField(15);

		panel = new JPanel();
		panel1 = new JPanel();
		panel2 = new JPanel();

		panel.setLayout(new GridLayout(4, 4, 4, 4));
		buttons = new JButton[16];

		int index = 0;
		for (int rows = 0; rows < 4; rows++) {
			for (int cols = 0; cols < 4; cols++) {
				buttons[index] = new JButton(labels[index]);
				buttons[index].addActionListener(this);
				if (index == 3 || index == 7 || index == 11 || index == 15) {
					buttons[index].setBackground(Color.pink);
					buttons[index].setFont(new Font("����", Font.PLAIN, 20));

				} else if (index == 12 || index == 14) {
					buttons[index].setBackground(Color.orange);
					buttons[index].setFont(new Font("����", Font.ITALIC, 17));
				} else {
					buttons[index].setBackground(Color.green);
					buttons[index].setFont(new Font("�ü�", Font.BOLD, 18));
				}
				panel.add(buttons[index]);
				index++;
			}
		}

		add(panel1, BorderLayout.NORTH);
		panel1.add(new JLabel("���� �Է�"));
		panel1.add(tField);
		panel1.setBackground(Color.gray);

		add(panel2, BorderLayout.SOUTH);
		panel2.add(new JLabel("��� ���"));
		panel2.add(tField1);
		panel2.setBackground(Color.white);

		add(panel, BorderLayout.CENTER);

		setVisible(true);
	}

	public static boolean is_number(String str) {
		try {
			double d = Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			return false; // ���� �߻��� ���ڰ� �ƴ�
		}
		return true;
	}

	protected void init() {
		tempName = "";
		tempString = "";
		bool = false;
		vec.clear();
	}

	private String tempName;
	private String tempString;
	private boolean bool = false;
	Vector<String> vec = new Vector<String>();

	public void actionPerformed(ActionEvent e) {
		try {
			// ���� ��ư�� �������� �޾���
			tempName = e.getActionCommand();

			// CE�� �������� ���ڿ��� �ʱ�ȭ
			if (tempName.equals("CE")) {
				tField.setText("");
				init();
				return;
			}

			// ���ݱ��� �Էµ� ���ڿ��� tempString���ٰ� �־���
			tempString = tField.getText();

			// �� ó�� 0�� �Էµ� ���¿��� ���ڸ� �Է��ϸ� �տ� �ִ� 0�� ����
			if (is_number(tempName) && tempString.equals("0")) {
				tField.setText(tempName);
			}

			else if (tempString.equals("") && !is_number(tempName)) {
				tField.setText("");
			}
			// �����ڰ� �Էµ� ���¿��� �����ڰ� �ԷµǴ� ��� �ٲ���
			else if (bool
					&& (tempName.equals("+") || tempName.equals("-") || tempName.equals("x") || tempName.equals("/"))) {
				tempString = tempString.substring(0, tempString.length() - 1);
				tField.setText(tempString + tempName);
			}

			// ���� ��ư �Է� ��
			else if (is_number(tempName)) {
				tField.setText(tempString + tempName);
				bool = false;
			}

			// ������ ��ư �Է� ��
			else if (!bool
					&& (tempName.equals("+") || tempName.equals("-") || tempName.equals("x") || tempName.equals("/"))) {
				tField.setText(tempString + tempName);
				bool = true;
			}
			// ����ư �Է� ��
			else if (tempName.equals("=")) {
				StringTokenizer st = new StringTokenizer(tempString, "+/-x", true);

				while (st.hasMoreTokens()) {
					vec.add(st.nextToken());
				}
				for (int i = 0; i < vec.size(); i++) {
					if (vec.get(i).equals("x")) {
						String a = String.valueOf(calculate(Double.parseDouble(vec.get(i - 1)),
								Double.parseDouble(vec.get(i + 1)), vec.get(i)));
						vec.remove(i - 1);
						vec.remove(i - 1);
						vec.remove(i - 1);
						vec.add(i - 1, a);
						i = 0;
					}
					if (vec.get(i).equals("/")) {
						String a = String.valueOf(calculate(Double.parseDouble(vec.get(i - 1)),
								Double.parseDouble(vec.get(i + 1)), vec.get(i)));
						vec.remove(i - 1);
						vec.remove(i - 1);
						vec.remove(i - 1);
						vec.add(i - 1, a);
						i = 0;
					}
				}
				for (int i = 0; i < vec.size(); i++) {
					if (vec.get(i).equals("+") || vec.get(i).equals("-")) {
						String a = String.valueOf(calculate(Double.parseDouble(vec.get(i - 1)),
								Double.parseDouble(vec.get(i + 1)), vec.get(i)));
						vec.remove(i - 1);
						vec.remove(i - 1);
						vec.remove(i - 1);
						vec.add(i - 1, a);
						i = 0;
					}
				}

				if (vec.get(0).equals("Infinity")) {
					tField1.setText("0���� ����� �� �����ϴ�!");
				} else {
					double qwe = Double.parseDouble(vec.get(0));
					int asd = (int) qwe;
					if (qwe - asd == 0.0) {
						vec.remove(0);
						vec.add(asd + "");
					}
					tField1.setText(vec.get(0));
				}
				vec.clear();
			}
		} catch (Exception ex) {
			tField.setText("");
			tField1.setText("������ ����� �Է����ּ���!");
			init();
		}

	}

	public double calculate(double a, double b, String c) {
		switch (c) {
		case "+":
			return a + b;
		case "-":
			return a - b;
		case "x":
			return a * b;
		case "/":
			return a / b;
		default:
			return -1;
		}
	}

	public static void main(String[] args) {
		new calculator();
	}
}